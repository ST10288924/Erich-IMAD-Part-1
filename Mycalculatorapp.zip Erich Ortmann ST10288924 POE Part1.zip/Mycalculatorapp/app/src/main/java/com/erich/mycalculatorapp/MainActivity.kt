package com.erich.mycalculatorapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    // Initialize references to UI components
    private lateinit var num1editTextNumber:EditText
    private lateinit var num2editTextNumber:EditText
    private lateinit var resultTextView: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num1editTextNumber=findViewById(R.id.Num1editTextNumber)
        num2editTextNumber=findViewById(R.id.Num2editTextNumber)
        resultTextView = findViewById(R.id.textViewAnswer)

        // set click listeners for operation buttons
       val buttonAdd = findViewById<Button>(R.id.buttonAdd)
       val buttonSubtract=findViewById<Button>(R.id.buttonSubtract)
       val buttonMultiply=findViewById<Button>(R.id.buttonMultiply)
       val buttonDivide=findViewById<Button>(R.id.buttonDivide)
        val clearbutton=findViewById<Button>(R.id.clearbutton)

        buttonAdd.setOnClickListener{ performCalculation("+")}
        buttonSubtract.setOnClickListener{ performCalculation("-")}
        buttonMultiply.setOnClickListener{ performCalculation("*")}
        buttonDivide.setOnClickListener{ performCalculation("/")}
        clearbutton.setOnClickListener{
            num1editTextNumber.setText("")
            num2editTextNumber.setText("")
            resultTextView.text=""
        }

    }

        @SuppressLint("SetTextI18n")
         private fun performCalculation (operation: String) {
            //Parse the input numbers as integers: if parsing fails, return
            val num1=num1editTextNumber.text.toString().toIntOrNull() ?: return
            val num2=num2editTextNumber.text.toString().toIntOrNull() ?: return

            // perform the section arithmetic operation
            val result: Number = when (operation) {
                "+" -> num1 + num2
                "-" -> num1 - num2
                "*" -> num1 * num2
                "/" -> if (num2 != 0) num1 / num2 else Double.NaN
                else -> Double.NaN
            }
                //Display the result in textViewAnswer
                resultTextView.text= "Result: $num1 $operation $num2= $result"
            }
        }



